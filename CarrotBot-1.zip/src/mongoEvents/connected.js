module.exports = {
	name: 'connected',
	execute() {
		console.log(`Connected to Database.`);
	},
};