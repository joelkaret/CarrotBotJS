module.exports = {
	name: 'err',
	execute(error) {
		console.log(error);
	},
};