module.exports = {
	name: 'disconnected',
	execute() {
		console.log(`Disconnected from Database.`);
	},
};