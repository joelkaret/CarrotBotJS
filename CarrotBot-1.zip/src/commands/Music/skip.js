const { SlashCommandBuilder } = require("discord.js");
module.exports = {
    data: new SlashCommandBuilder()
        .setName("skip")
        .setDescription("skip current song"),
    async execute(interaction) {
		await interaction.reply('Working...')
		
        try{
        const queue = interaction.client.player.nodes.get(interaction.guild)

        if (!queue || !queue.isPlaying()) {
            return interaction.editReply({ content: "There is nothing playing" })
        }

        const currentTrack = queue.current
        const success = queue.node.skip()
        return interaction.editReply({ content: `Skipped ${queue.currentTrack}` })
    }catch (error) {
        console.log(error)
    }
    }
}