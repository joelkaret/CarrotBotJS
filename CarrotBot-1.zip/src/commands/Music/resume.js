const { SlashCommandBuilder } = require("discord.js");
module.exports = {
    data: new SlashCommandBuilder()
        .setName("resume")
        .setDescription("resume"),
    async execute(interaction) {
		await interaction.reply('Working...')
		
        try{
        const queue = interaction.client.player.nodes.get(interaction.guild)

        if (!queue || !queue.isPlaying()) {
            return interaction.editReply("There is nothing playing")
        }

        const paused = queue.node.setPaused(false)
        return interaction.editReply("resumed successfully")
    }catch (error) {
        console.log(error)
    }
}
}